# notehb
Collaborative Live Note Taking

Made by Rikin Katyal and Michal Jez
